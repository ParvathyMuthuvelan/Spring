package com.springjdbc;



import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.springjdbc.model.Person;
import com.springjdbc.service.PersonServiceImpl;


@ComponentScan("com.springjdbc")
public class Main{

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfiguration.class);
		PersonServiceImpl personService = context.getBean(PersonServiceImpl.class);
		//System.out.println(service);
		System.out.println("------Listing Multiple Records--------");
		List<Person> list=personService.listPersons();
		for (Person record : list) {
			System.out.print("ID : " + record.getId());
			System.out.print(", Name : " + record.getName());
			System.out.println(", Age : " + record.getAge());
		}
		System.out.println("----Inserting record -----");
		personService.create("Minu", 26);
		
		System.out.println("----Listing Record with ID = 3 -----");
	Person person = personService.getPerson(3);
		System.out.print("ID : " + person.getId());
		System.out.print(", Name : " + person.getName());
		System.out.println(", Age : " + person.getAge());

		}

}