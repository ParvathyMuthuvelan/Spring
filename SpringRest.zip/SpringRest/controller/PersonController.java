package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.restservice.Person;
import com.training.service.PersonService;

@RestController
public class PersonController {
	@Autowired
	PersonService personService;

	@DeleteMapping("/persons/{id}")
	// @RequestMapping(value = "/persons/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> delete(@PathVariable("id") int id) {
		personService.remove(id);
		return new ResponseEntity<>("Person is deleted successsfully", HttpStatus.OK);
	}
	@PutMapping("/persons/{id}")
	//@RequestMapping(value = "/persons/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Object> updateProduct(@PathVariable("id") int id, @RequestBody Person person) {
		//personService.remove(id);
		//person.setId(id);
		
		personService.put(id, person);
		return new ResponseEntity<>("Person is updated successsfully", HttpStatus.OK);
	}
	@PostMapping("/persons/add")
	//@RequestMapping(value = "/persons", method = RequestMethod.POST)
	public ResponseEntity<Object> createProduct(@RequestBody Person person) {
		personService.put(person.getId(), person);
		return new ResponseEntity<>("Person is created successfully", HttpStatus.CREATED);
	}
	@GetMapping("/persons")
	//@RequestMapping(value = "/persons")
	public ResponseEntity<Object> getProduct() {
		return new ResponseEntity<>(personService.getAll(), HttpStatus.OK);
	}

	@GetMapping("/persons/{id}")
	public ResponseEntity<Person> findPersonById(@PathVariable(value = "id") int id) {
		Person person = personService.findById(id);

		if (person != null) {
			return ResponseEntity.ok().body(person);
		} else {
			return ResponseEntity.notFound().build();
		}
	}
}
