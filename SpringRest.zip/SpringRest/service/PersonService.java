package com.training.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Service;

import com.example.restservice.Person;

@Service
public class PersonService {
	private static Map<Integer, Person> personRepo = new HashMap<>();

	public void remove(int id) {
		personRepo.remove(id);

	}

	public void put(int id, Person person) {
		personRepo.put(id, person);

	}

	public List<Person> getAll() {
		List<Person> personList = new ArrayList<>();
		for (Entry<Integer, Person> entry : personRepo.entrySet()) {
			personList.add(entry.getValue());
		}
		return personList;
	}

	public Person findById(int id) {
		Person person = personRepo.get(id);
		return person;
	}

}
