package com.spring.aop;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class App {
	public static void main(String[] args) throws Exception {
		
		
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AopConfig.class);

		 CustomerBoImpl customer =context.getBean(CustomerBoImpl.class);
		    //customer.addCustomer();
		 // System.out.println(customer.addCustomerReturnValue());
		customer.addCustomerThrowException();
		   //customer.addCustomerAround("sai");
	}
	
}
