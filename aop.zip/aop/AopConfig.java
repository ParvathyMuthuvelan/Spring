package com.spring.aop;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

//Type your code here
//Type your code here
//Type your code here
@Configuration
@ComponentScan({"com.spring.aop.*"})
@EnableAspectJAutoProxy
public class AopConfig {
	@Bean
	public CustomerBoImpl getCustomerBoImpl() 
	{
		return new CustomerBoImpl();
	}
	@Bean
	public LoggingAspect getLoggingAspect()
	{
		return new LoggingAspect();
	}
	
}
