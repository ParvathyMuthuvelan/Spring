package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.bean.Employee;
import com.exception.EmployeeNotFoundException;
import com.service.EmployeeService;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;
	
	@ModelAttribute("emp")
	public Employee getEmployee()
	{
		return new Employee();
	}

	
	@RequestMapping("/getEmployees")
	public  String getEmployees(ModelMap model)
	{
		List<Employee> empList=employeeService.fetchEmployees();
		
		model.addAttribute("emplist",empList);
		
		return "employeesListDisplay";
		
	}
//	@ExceptionHandler(value = EmployeeNotFoundException.class)
//	   public ModelAndView exception(EmployeeNotFoundException exception) {
//	   ModelAndView model=new ModelAndView();
//	   model.setViewName("error");
//	   model.addObject("errorMsg","Employee not found");
//	      return model;
//	   }
	
	//@ExceptionHandler(EmployeeNotFoundException.class)
	//@ResponseStatus(value=HttpStatus.NOT_FOUND)  
	@RequestMapping(value="/findEmployee",method=RequestMethod.GET)
	public String findEmployee(@RequestParam("id") int id,ModelMap model)
	
	{
		//System.out.println("find "+id);
		Employee employee=employeeService.getEmployee(id);
		System.out.println("find "+employee);
		if(employee==null)
		{
			//System.out.println("exception");
			throw new EmployeeNotFoundException();
		}
		model.addAttribute("emp", employee);
		return "employeeDisplay";
		
	}
	@RequestMapping(value="/createEmployee",method=RequestMethod.GET)
	public  String createEmployeePage(@ModelAttribute("emp") Employee emp)
	{
		//ModelAndView mv=new ModelAndView("employeeForm","command",new Employee());
		//return mv;
		return "employeeForm";
		}
		
	@PostMapping(value="/addEmployee")
	public  String addEmployee(@ModelAttribute("emp")Employee emp)
	{
		employeeService.addEmployee(emp);
		return "redirect:/employee/getEmployees";
		}
	//showEditEmployee/1
	//showEditEmployee/2
	@RequestMapping("/showEditEmployee/{employeeId}")
	public String showEditEmployeePage(Model model,@PathVariable("employeeId")int empId)
    {
		System.out.println(empId);
        Employee employee=employeeService.getEmployee(empId);
       
      model.addAttribute("command", employee);
        return "editEmployee";
    }
	 @PostMapping(value = "/update")
	    public String updateEmployee(@ModelAttribute("emp")Employee emp)
	    {
	    	
	    employeeService.updateEmployee(emp);
	        return "redirect:/employee/getEmployees";
	    }
	 @RequestMapping(value = "/deleteEmployee/{employeeId}")
	    public String deleteEmployee(@PathVariable("employeeId")  int empId)
	    {
	    	
	    	employeeService.deleteEmployee(empId);
	        return "redirect:/employee/getEmployees";
	    }
	 
}






