package com.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.bean.Employee;

@Repository
public class EmployeeDaoCollectionImpl implements EmployeeDao{
static List<Employee> empList=null;
public EmployeeDaoCollectionImpl()
{
	if (empList==null)
		empList=new ArrayList<>();
	}
	@Override
	public List<Employee> fetchEmployees() {
	
		return empList;
	}

	@Override
	public void addEmployee(Employee emp) {
	
		empList.add(emp);
		
	}

	@Override
	public Employee getEmployee(int empId) {
		Employee emp=null;
		for(Employee e:empList)
		{
			if(e.getEmployeeId()==empId)
			{
				emp=e;
				break;
			}
		}
		return emp;
	}

	@Override
	public void updateEmployee(Employee emp) {
		
		int index=0;
		int listSize=empList.size();
		for(int i=0;i<listSize;i++)
		{
			if(empList.get(i).getEmployeeId()==emp.getEmployeeId())
			{
				index=i;
				break;
			}
		}
		empList.set(index,emp);
		
	}

	@Override
	public void deleteEmployee(int empId) {
	Iterator<Employee> itr=empList.iterator();
	Employee emp=null;
	while(itr.hasNext())
	{
		emp=itr.next();
		if(emp.getEmployeeId()==empId)
		{
			itr.remove();
		}
	}
	
		
	}

}
