package com.spring.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAop {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");

		EmployeeManagerImpl manager = context.getBean("employee", EmployeeManagerImpl.class);

		System.out.println(manager.getEmployeeById(1));

		manager.updateEmployee(new Employee());
		manager.deleteEmployee(100);

		manager.createEmployee(new Employee());
	}
}
